
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void print_flag() {
    char f[] = {102,108,97,103,123, 98,117,102,102,51,114, 95,98,117,115,116,51,100, 95,104,51,108,108,48, 95,119,48,114,108,100,125, 0};
    puts(f);
}

void greet() {
    char name[32];
    printf("What's your name?\n> ");
    gets(name);  
    printf("Hello, %s!\n", name);
}

int main() {
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
    greet();
    return 0;
}
